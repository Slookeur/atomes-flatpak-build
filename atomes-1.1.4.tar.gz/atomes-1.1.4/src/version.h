#define FC "C:/msys64/mingw64/bin/x86_64-w64-mingw32-gfortran 10.2.0"
#define FCFLAGS "-O3 -cpp"
#define CC "C:/msys64/mingw64/bin/x86_64-w64-mingw32-gcc "
#define CFLAGS "-O3"
