If you would like to contribute to the development of **atomes**:

  - Any new file / function should include approriate description and commentary in the [Doxygen](https://www.doxygen.nl/) format
  - Changes to atomes should be submitted for review through pull-request. 
  - Bugs should be filled on GitHub issue tracker: [issue](https://github.com/Slookeur/Atomes-GNU/issues)

