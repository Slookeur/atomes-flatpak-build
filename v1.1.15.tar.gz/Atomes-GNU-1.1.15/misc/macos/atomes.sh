#!/bin/sh

GSK_RENDERER=gl atomes-bin $@
