Welcome to **atomes** !

Detailed installation instruction can be found on the web site: 

[https://atomes.ipcms.fr/](https://atomes.ipcms.fr/)

For basic help after compilation and/or installation: 

atomes -h
atomes --help

For version information:

atomes -v
atomes --version
